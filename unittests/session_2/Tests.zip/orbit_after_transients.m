function output_orbit = orbit_after_transients(a) 
  % :param a: Parameter of the logistic map
  % :returns: An array containing the orbit of the logistic map without transients
end