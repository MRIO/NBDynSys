function fighandle = bifurcationdiagram(as, varargin)	
  % :param as: Array of range of parameters
  % :param varargin: Variable argument to handle figure handle
  % :returns: Figure handle containing the figure of a bifurcation diagram of the logistic map

end