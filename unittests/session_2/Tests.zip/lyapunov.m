function fighandle = lyapunov(as, varargin) 
  % :param as: Array of range of parameters
  % :param varargin: Variable argument to handle figure handle
  % :returns: Figure handle containing the figure of a plot of the Lyapunov exponent vs the parameter of the logistic map


end